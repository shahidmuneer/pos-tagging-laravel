<?php $__env->startSection('content'); ?>
    <div class="container margin-top-40">

        <ul class="nav nav-tabs">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a class="nav-link nav-link1 <?php if($category->id==$value->id): ?><?php echo e('active'); ?><?php endif; ?>" href="<?php echo e(route('browse', $value->id)); ?>?search=<?php echo e(old('search')); ?>"><?php echo e($value->type_name); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <!-- Tab panes -->
        <div class="tab-content" style="margin-top: 30px;">
            <div class="tab-pane container active" id="<?php echo e($category->table_name); ?>">
                <?php if($category->id == 5): ?>
                    <?php if(sizeof($result) > 0): ?>
                        <p>Search Results</p>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="container">
                                <a href="<?php echo e(route('write', [$category->id, $value['track_id']])); ?>">
                                        <?php $title = []; ?>
                                        <?php $__currentLoopData = ['.',',',':',';',"'"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $character): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(str_contains($value['lyrics_body'], $character)): ?>
                                                <?php $title[strlen(explode($character, $value['lyrics_body'])[0])] = explode($character, $value['lyrics_body'])[0]; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($title): ?>
                                            <?php $pieces = explode(" ", trim($title[min(array_keys($title))])); $first_part = implode(" ", array_splice($pieces, 0, 10)); $other_part = implode(" ", array_splice($pieces, 10)); ?>
                                            <h3 style="color: #F7898E"><?php echo e($first_part); ?></h3>
                                        <?php else: ?>
                                            <?php $pieces = explode(" ", trim($value['lyrics_body'])); $first_part = implode(" ", array_splice($pieces, 0, 10)); $other_part = implode(" ", array_splice($pieces, 10)); ?>
                                            <h3 style="color: #F7898E"><?php echo $first_part; ?></h3>
                                        <?php endif; ?>
                                </a>
                                <?php if(isset($value['lyrics_body'])): ?>
                                    <?php $pieces = explode(" ", trim($value['lyrics_body'])); $first_part = implode(" ", array_splice($pieces, 0, 150)); $other_part = implode(" ", array_splice($pieces, 150)); ?>
                                    <p><?php echo $first_part; ?></p>
                                <?php else: ?>
                                    <p>No Lyrics Available</p>
                                <?php endif; ?>
                                <p>Artist: <span style="color: #F7898E"><?php echo e($value['lyrics_artist']); ?></span></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p>No Result Found</p>
                    <?php endif; ?>
                <?php else: ?>
                    <?php if($result->count() > 0): ?>
                        <p>Search Results</p>
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="container">
                                <a href="<?php echo e(route('write', [$category->id, $value->{$category->type_name .'_id'}])); ?>">
                                    <?php if(isset($value->{'str'. $category->type_name .'_title'})): ?>
                                        <?php $pieces = explode(" ", trim($value->{'str'. $category->type_name .'_title'})); $first_part = implode(" ", array_splice($pieces, 0, 10)); $other_part = implode(" ", array_splice($pieces, 10)); ?>
                                        <h3 style="color: #F7898E"><?php echo e($first_part); ?></h3>
                                    <?php else: ?>
                                        <?php $title = []; ?>
                                        <?php $__currentLoopData = ['.',',',':',';']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $character): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(str_contains($value->{'str'. $category->type_name .'_body'}, $character)): ?>
                                                <?php $title[strlen(explode($character, $value->{'str'. $category->type_name .'_body'})[0])] = explode($character, $value->{'str'. $category->type_name .'_body'})[0]; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($title): ?>
                                            <?php $pieces = explode(" ", trim($title[min(array_keys($title))])); $first_part = implode(" ", array_splice($pieces, 0, 10)); $other_part = implode(" ", array_splice($pieces, 10)); ?>
                                            <h3 style="color: #F7898E"><?php echo e($first_part); ?></h3>
                                        <?php else: ?>
                                            <?php $pieces = explode(" ", trim($value->{'str'. $category->type_name .'_body'})); $first_part = implode(" ", array_splice($pieces, 0, 10)); $other_part = implode(" ", array_splice($pieces, 10)); ?>
                                            <h3 style="color: #F7898E"><?php echo $first_part; ?></h3>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </a>
                                <?php $pieces = explode(" ", trim($value->{'str'. $category->type_name .'_body'})); $first_part = implode(" ", array_splice($pieces, 0, 150)); $other_part = implode(" ", array_splice($pieces, 150)); ?>
                                <p><?php echo $first_part; ?></p>
                                <p>Author: <span style="color: #F7898E"><?php echo e($value->{'str'. $category->type_name .'_author'}); ?></span></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($result->appends($_GET)->links()); ?>

                    <?php else: ?>
                        <p>No Result Found</p>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {

        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['nav_search'=>true, 'black_footer'=>true, 'page'=>'browse'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Development\RogProjects\upwork\IGaming\resources\views/browse.blade.php ENDPATH**/ ?>