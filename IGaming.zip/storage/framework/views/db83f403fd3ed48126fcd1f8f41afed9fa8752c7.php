<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 text-center">
                <h3 class="margin-top-150 color-red">Learn to Write Well</h3>

                <form method="get" action="<?php echo e(route('show', $category->id)); ?>">
                    <div class="input-group">
                        <input type="text" class="form-control" name="search" placeholder="Search by Author, Title, or Keyword | <?php echo e($category->type_name); ?>" value="<?php echo e(old('search')); ?>">
                        <div class="input-group-append">
                            <button class="btn btn-secondary" type="submit">
                                <i class="fa fa-search color-black"></i>
                            </button>
                        </div>
                    </div>
                </form>
                <?php if(!isset($result)): ?>
                    <p class="margin-bottom-0">Practice the pace and structure <span class="display-block">of masters to find your own style</span></p>
                <?php endif; ?>
            </div>
            <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12">
            </div>
        </div>

        <?php if(isset($result)): ?>
            <?php if($result->count() > 0): ?>
                <div class="row mb-5">
                    <div class="col-lg-12">
                        <div class="table-responsive text-nowrap">
                            <!--Table-->
                            <table class="table table-striped">

                                <!--Table head-->
                                <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Author</th>
                                    <th>Title</th>
                                    <th>Keywords</th>
                                </tr>
                                </thead>
                                <!--Table head-->

                                <!--Table body-->
                                <tbody>
                                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($key+1); ?></th>
                                        <td><?php echo e($value->{'str'. $category->type_name .'_author'}); ?></td>
                                        <td><?php echo e($value->{'str'. $category->type_name .'_title'}); ?></td>
                                        <td><?php echo e($value->{'str'. $category->type_name .'_keywords'}); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <!--Table body-->


                            </table>
                        </div>
                        <div class="text-center">
                            <?php echo e($result->appends($_GET)->links()); ?>

                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="text-center mb-5">
                    <p><b>Record not found</b></p>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="mt-50 text-center "> <a href="#" class="">Learn more <br><i class="fa fa-angle-down fa-2x" aria-hidden="true"></i></a></div>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Development\RogProjects\upwork\IGaming\resources\views/index.blade.php ENDPATH**/ ?>