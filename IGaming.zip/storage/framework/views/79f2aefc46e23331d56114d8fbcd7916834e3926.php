<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Pos tagging')); ?></title>

    <!-- Styles -->

    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- BootStrap -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">

    <!-- Custom -->
    <link rel="stylesheet" href="<?php echo e(asset('css/index.css')); ?>">

    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body>
<div id="app">
    <header>
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>">

                    Logo
                </a>
                <?php if(isset($nav_search)): ?>
                    <ul class="navbar-nav">
                        <form method="get" action="<?php echo e(route($page, $category->id)); ?>">
                            <div class="input-group" style="margin-top: 5px; margin-bottom: 5px;">
                                <input type="text" class="form-control br-0"  placeholder="Search by Author, Title, or Keyword" name="search" value="<?php echo e(old('search')); ?>">
                                <div class="dropdown">
                                    <button type="button" class="btn" data-toggle="dropdown" style="border-radius: 0; border-left: 0;">
                                        | <?php echo e($category->type_name); ?>

                                    </button>
                                    <div class="dropdown-menu">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a class="dropdown-item" href="<?php echo e(route($page=='write'?'browse':$page, $value->id)); ?>"><?php echo e($value->type_name); ?></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>

                                <div class="input-group-append">
                                    <button class="btn btn-secondary" type="submit">
                                        <i class="fa fa-search" style="color: #F7898E;"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </ul>
                <?php endif; ?>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-list-7">
                    <span><i class="fa fa-bars"></i> </span>
                </button>
                <div class="collapse navbar-collapse justify-content-between" id="navbar-list-7">
                    <ul class="navbar-nav"></ul>
                    <span class="navbar-text">
                        <ul class="navbar-nav" id="navbar-categories">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="nav-item"><a <?php if($category->id==$value->id): ?>style="color: blue; font-weight: normal;"<?php endif; ?> href="<?php echo e(route($page=='write'?'browse':$page, $value->id)); ?>" class="nav-link log-in"><?php echo e($value->type_name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </span>
                </div>
            </div>
        </nav>
    </header>

    <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php if(isset($black_footer)): ?>
        <div class="footer-black">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-10 col-md-9">
                        <p>Lybr, inc , copyright 2022</p>
                    </div>
                    <div class="col-lg-2 col-md-3">
                        <div><a href="#" style="color: white">Help</a> | <a href="#" style="color: white">Privacy</a> | <a href="#" style="color: white">Terms</a></div>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <footer class="mr-3 ml-3">
            <div class="position">Lybr, inc , copyright 2022<br><a href="#">Help</a> | <a href="#">Privacy</a> | <a href="#">Terms</a></div>
        </footer>
    <?php endif; ?>
    <?php echo $__env->yieldContent('modals'); ?>

</div>

<!-- Scripts -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<script>
</script>
<?php echo $__env->yieldContent('scripts'); ?>

</body>

</html>
<?php /**PATH E:\Development\RogProjects\upwork\IGaming\resources\views/layouts/app.blade.php ENDPATH**/ ?>