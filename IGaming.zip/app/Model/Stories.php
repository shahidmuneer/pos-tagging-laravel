<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Stories extends Model
{
    protected $table = 'tblpost_stories';
}
