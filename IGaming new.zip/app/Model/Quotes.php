<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Quotes extends Model
{
    protected $table = 'tblpost_quotes';
}
