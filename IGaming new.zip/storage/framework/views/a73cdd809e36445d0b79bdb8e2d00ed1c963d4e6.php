<?php $__env->startSection('content'); ?>
    <div class="container margin-top-40">

        <h2 class="text-center" id="saved-title"></h2>
        <p class="text-center" id="saved-body"></p>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            $('#saved-title').append((localStorage.getItem('title')||'')+'<br>'+(localStorage.getItem('name')||'')+'<br><span>|</span>');
            $('#saved-body').append(localStorage.getItem('body')||'_____');
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['nav_search'=>true, 'black_footer'=>true, 'page'=>'browse'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Development\RogProjects\upwork\IGaming\resources\views/show.blade.php ENDPATH**/ ?>