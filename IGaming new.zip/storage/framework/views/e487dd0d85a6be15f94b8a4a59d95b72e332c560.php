<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
    integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

  <title>POS Tagger</title>
</head>

<body>
  <div class="container">
    <h1>POS</h1>
    
    <nav>
      <div class="nav nav-tabs" id="nav-tab" role="tablist">
        <a class="nav-link active" id="nav-postag-tab" data-toggle="tab" href="#postag" role="tab" aria-controls="postag"
          aria-selected="true">POS tagging</a>
        <a class="nav-link" id="nav-about-tab" data-toggle="tab" href="#about" role="tab"
          aria-controls="about" aria-selected="false">about POS</a>
      </div>
    </nav>
    <div class="tab-content" id="nav-tabContent">
      <div class="tab-pane fade show active" id="postag" role="tabpanel" aria-labelledby="postag-tab">
        <div class="row" id="postagSection">
          <div class="col-md-8">
            <p class="hidden-xs hidden-sm">Enter a <strong>complete sentence</strong> (no single words!) and click at "POS-tag!".
              The tagging works better when grammar and orthography are correct.</p>
            <div id="form">
              <div class="form-group">
                <label for="text" class="hidden-xs hidden-sm">Text:</label>
                <textarea class="form-control show-edit" rows="2"
                  id="text">John likes the blue house at the end of the street.</textarea>
                <div id="textTagged" class="show-view"style="display: none">
                  
                </div>
                
              </div>
              <div id="tagTipContainer" class="show-view" style="display: none;">
                <div class="up">&#9650;</div>
                <div id="tagTip"><b>Noun</b>, NNP</div>
              </div>
              <div class="btn-toolbar" role="toolbar" aria-label="Toolbar with button groups">
                <div class="btn-group mr-2" role="group" aria-label="First group" id="posBtn">
                  <button type="button" class="btn btn-light show-edit" id="posButton"><i class="fa fa-check" aria-hidden="true"></i> POS-tag!</button>
                </div>
                <div class="btn-group mr-2" role="group" aria-label="Second group" id="editBtn" style="display: none;">
                  <button type="button" class="btn btn-light show-edit" id="editButton"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit Text</button>
                </div>
                <!-- <div class="btn-group" role="group" aria-label="Third group">
                  <button type="button" class="btn btn-light"><i class="fa fa-wrench" aria-hidden="true"></i></button>
                </div> -->
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div id="colors">
              <div class="tagAdjective">Adjective</div>
              <div class="tagAdverb">Adverb</div>
              <div class="tagConjunction">Conjunction</div>
              <div class="tagDeterminer">Determiner</div>
              <div class="tagInterjection">Interjection</div>
              <div class="tagNoun">Noun</div>
              <div class="tagNumber">Number</div>
              <div class="tagPreposition">Preposition</div>
              <div class="tagPronoun">Pronoun</div>
              <div class="tagVerb">Verb</div>
            </div>
          </div>
        </div>
      </div>
      <div class="tab-pane fade" id="about" role="tabpanel" aria-labelledby="about-tab">
        <div class="row" id="aboutSection">
          <div class="col-md-8">
            <p>The core of POS is based on the <a href="#">Stanford
                University Part-Of-Speech-Tagger</a>.</p>
            <p>Please be aware that these machine learning techniques might never reach 100 % accuracy.</p>
          </div>
          <div class="col-md-4">
            <div class="card">
              <h5 class="card-header">Links</h5>
              <div class="card-body">
                <ul>
                  <li><a href="#">Wikipedia about Parts-of-speech</a></li>
                  <li><a href="#">Stanford POS-Tagger</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <hr>
        
        <footer>
          <p>
            <a href="#">Contact/Imprint</a> |
            <a href="#">Privacy</a> |
            <a href="#">de</a> |
            <a href="#">en</a> |
            <a href="#">fr</a>
          </p>
        </footer>
      </div>
    </div>
  </div>

  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF"
    crossorigin="anonymous"></script>

    <script src="https://use.fontawesome.com/801a6fbbd0.js"></script>
    <script>
    
      $(function () {
          var appData = {"global":{"languages":["de","en","es","hu","it","fr"],"pos":["Adjective","Adverb","Conjunction","Determiner","Interjection","Noun","Number","Preposition","Pronoun","Verb"]},"i18n":{"label_examples":"Examples: ","Adjective":"Adjective","Adverb":"Adverb","Conjunction":"Conjunction","Determiner":"Determiner","Interjection":"Interjection","Noun":"Noun","Number":"Number","Preposition":"Preposition","Pronoun":"Pronoun","Verb":"Verb"},"de":{"langauge":"de","tagMap":{"ADJ":["Adjective","","[das] gro\u00dfe [Haus]"],"ADV":["Adverb","","schon, bald, doch"],"INTJ":["Interjection","","mhm, ach, tja"],"NOUN":["Noun","","Tisch, Herr, [das] Reisen"],"PROPN":["Noun","Eigenname","Hans, Hamburg, HSV"],"VERB":["Verb","","gehen, sprechen, sehen"],"ADP":["Preposition","","in [der Stadt], ohne [mich]"],"AUX":["Verb","Hilfsverb",""],"CCONJ":["Conjunction","nebenordnende Konjunktion","weil, da\u00df, damit, wenn, ob"],"DET":["Determiner","","der, die, das, ein, eine"],"NUM":["Number","","zwei [M\u00e4nner], [im Jahre] 1994"],"PART":["","Partikel","am [sch\u00f6nsten], zu [schnell]"],"PRON":["Pronoun","","er, sie, ich, welche,dieser, jener"],"SCONJ":["Conjunction","unterordnende Konjunktion","und, oder, aber"]},"posAvailable":["Adjective","Adverb","Conjunction","Determiner","Interjection","Noun","Number","Preposition","Pronoun","Verb"]},"en":{"language":"en","tagMap":{"!":[".","",""],"#":[".","",""],"$":[".","",""],"''":[".","",""],"(":[".","",""],")":[".","",""],",":[".","",""],"-LRB-":[".","",""],"-RRB-":[".","",""],".":[".","",""],":":[".","",""],"?":[".","",""],"CC":["Conjunction","",""],"CD":["Number","",""],"CD|RB":["X","",""],"DT":["Determiner","",""],"EX":["Determiner","",""],"FW":["X","",""],"IN":["Preposition","",""],"IN|RP":["Preposition","",""],"JJ":["Adjective","",""],"JJR":["Adjective","",""],"JJRJR":["Adjective","",""],"JJS":["Adjective","",""],"JJ|RB":["Adjective","",""],"JJ|VBG":["Adjective","",""],"LS":["X","",""],"MD":["Verb","",""],"NN":["Noun","",""],"NNP":["Noun","",""],"NNPS":["Noun","",""],"NNS":["Noun","",""],"NN|NNS":["Noun","",""],"NN|SYM":["Noun","",""],"NN|VBG":["Noun","",""],"NP":["Noun","",""],"PDT":["Determiner","",""],"POS":["PRT","",""],"PRP":["Pronoun","",""],"PRP$":["Pronoun","",""],"PRP|VBP":["Pronoun","",""],"PRT":["PRT","",""],"RB":["Adverb","",""],"RBR":["Adverb","",""],"RBS":["Adverb","",""],"RB|RP":["Adverb","",""],"RB|VBG":["Adverb","",""],"RN":["X","",""],"RP":["PRT","",""],"SYM":["X","",""],"TO":["PRT","",""],"UH":["X","",""],"VB":["Verb","",""],"VBD":["Verb","",""],"VBD|VBN":["Verb","",""],"VBG":["Verb","",""],"VBG|NN":["Verb","",""],"VBN":["Verb","",""],"VBP":["Verb","",""],"VBP|TO":["Verb","",""],"VBZ":["Verb","",""],"VP":["Verb","",""],"WDT":["Determiner","",""],"WH":["X","",""],"WP":["Pronoun","",""],"WP$":["Pronoun","",""],"WRB":["Adverb","",""],"``":[".","",""]},"posAvailable":["Adjective","Adverb","Conjunction","Determiner","Noun","Number","Preposition","Pronoun","Verb"]},"es":{"language":"es","tagMap":{"ADJ":["Adjective","",""],"ADV":["Adverb","",""],"INTJ":["Interjection","",""],"NOUN":["Noun","",""],"PROPN":["Noun",""],"VERB":["Verb","",""],"ADP":["Preposition","",""],"AUX":["Verb","",""],"CCONJ":["Conjunction","",""],"DET":["Determiner","",""],"NUM":["Number","",""],"PART":["","",""],"PRON":["Pronoun","",""],"SCONJ":["Conjunction",""]},"posAvailable":["Adjective","Adverb","Conjunction","Determiner","Noun","Number","Preposition","Pronoun","Verb"]},"hu":{"language":"fr","tagMap":{"ADJ":["Adjective","",""],"ADV":["Adverb","",""],"INTJ":["Interjection","",""],"NOUN":["Noun","",""],"PROPN":["Noun",""],"VERB":["Verb","",""],"ADP":["Preposition","",""],"AUX":["Verb","",""],"CCONJ":["Conjunction","",""],"DET":["Determiner","",""],"NUM":["Number","",""],"PART":["","",""],"PRON":["Pronoun","",""],"SCONJ":["Conjunction",""]},"posAvailable":["Adjective","Adverb","Conjunction","Determiner","Noun","Preposition","Pronoun","Verb"]},"it":{"language":"fr","tagMap":{"ADJ":["Adjective","",""],"ADV":["Adverb","",""],"INTJ":["Interjection","",""],"NOUN":["Noun","",""],"PROPN":["Noun",""],"VERB":["Verb","",""],"ADP":["Preposition","",""],"AUX":["Verb","",""],"CCONJ":["Conjunction","",""],"DET":["Determiner","",""],"NUM":["Number","",""],"PART":["","",""],"PRON":["Pronoun","",""],"SCONJ":["Conjunction",""]},"posAvailable":["Adjective","Adverb","Conjunction","Determiner","Noun","Preposition","Pronoun","Verb"]},"fr":{"language":"fr","tagMap":{"ADJ":["Adjective","",""],"ADV":["Adverb","",""],"INTJ":["Interjection","",""],"NOUN":["Noun","",""],"PROPN":["Noun",""],"VERB":["Verb","",""],"ADP":["Preposition","",""],"AUX":["Verb","",""],"CCONJ":["Conjunction","",""],"DET":["Determiner","",""],"NUM":["Number","",""],"PART":["","",""],"PRON":["Pronoun","",""],"SCONJ":["Conjunction",""]},"posAvailable":["Adjective","Adverb","Conjunction","Determiner","Noun","Preposition","Pronoun","Verb"]}};
          //console.log(appData.en.tagMap["DT"])
          $(document).on("mouseenter", ".taggedWord", function(){
                /*appData.en.tagMap[word[1]][0]
                <b>Noun</b>, NNP*/
                var classList = $(this).attr("class");
                let classes = classList.split(" ")
                var position = $(this).position();
                $('#tagTip').html(`<b>${classes[2]}</b>, ${classes[3]}`)
                $('#tagTipContainer').css('left', position.left)
                $('#tagTipContainer').css('top', position.top+ 22)
                $('#tagTipContainer').css('display', 'block')
                $('#tagTipContainer').addClass(classes[1]);
            });

            $(document).on("mouseleave", ".taggedWord",function(){
                var classList = $(this).attr("class");
                let classes = classList.split(" ")
                $('#tagTipContainer').removeClass(classes[1]);
                $('#tagTipContainer').css('display', 'none')
            });
            
          /*$('.taggedWord').hover(function () {
            var classList = $(this).attr("class");
            let requiredClass = classList.split(" ")[1]
            var position = $(this).position();
            $('#tagTipContainer').css('left', position.left)
            $('#tagTipContainer').css('top', position.top+ 22)
            $('#tagTipContainer').css('display', 'block')
            $('#tagTipContainer').addClass(requiredClass);

            //$(this).css('background-color', '#F00');
          },
            function () {
              var classList = $(this).attr("class");
              let requiredClass = classList.split(" ")[1]
              $('#tagTipContainer').removeClass(requiredClass);
              $('#tagTipContainer').css('display', 'none')
          });*/

          $('#posBtn').click(function () {
            $('#posButton').prop("disabled",true);
            let text = $('#text').val();
            $.ajax({url: "/pos?input="+text, success: function(result){
                $('#editBtn').css('display', 'block')
                $('#textTagged').css('display', 'block')
                $('#posBtn').css('display', 'none')
                $('#text').css('display', 'none')
                let output = result.output;
                        const myArray = output.split(" ");
                        let div = $("#textTagged").empty();
                        for (let i = 0; i < myArray.length; i++) {
                            let word = myArray[i].split("_")
                            console.log(word[0] + "   " + word[1])
                            div.append(` <span class="taggedWord tag${appData.en.tagMap[word[1]]!=undefined?appData.en.tagMap[word[1]][0]:""} ${appData.en.tagMap[word[1]]!=undefined?appData.en.tagMap[word[1]][0]:""}  ${word[1]}">${word[0]}</span> `);
                            /*if(word[1] === "JJ")
                                div.append(`<span class="taggedWord tagAdjective">${word[0]}</span>`);
                            else if(word[1] === "RB" || word[1] === "WRB")
                                div.append(`<span class="taggedWord tagAdverb">${word[0]}</span>`);
                            else if(word[1] === "DT")
                                div.append(`<span class="taggedWord tagDeterminer">${word[0]}</span>`);
                            else if(word[1] === "NN" || word[1] === "NNP" || word[1] === "NNS")
                                div.append(`<span class="taggedWord tagNoun">${word[0]}</span>`);
                            else if(word[1] === "CD")
                                div.append(`<span class="taggedWord tagNumber">${word[0]}</span>`);
                            else if(word[1] === "IN")
                                div.append(`<span class="taggedWord tagPreposition">${word[0]}</span>`);
                            else if(word[1] === "PRP")
                                div.append(`<span class="taggedWord tagPronoun">${word[0]}</span>`);
                            else if(word[1] === "VB" || word[1] === "VBZ" || word[1] === "VBP")
                                div.append(`<span class="taggedWord tagVerb">${word[0]}</span>`);
                            else
                                div.append(`<span class="taggedWord tagOther">${word[0]}</span>`);*/
                        }
                      
            }});
            
          })
          $('#editBtn').click(function () {
            $('#posButton').prop("disabled",false);
            $('#editBtn').css('display', 'none')
            $('#textTagged').css('display', 'none')
            $('#posBtn').css('display', 'block')
            $('#text').css('display', 'block')
          })
        })
    </script>

  <!-- Option 2: Separate Popper and Bootstrap JS -->
  <!--
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js" integrity="sha384-VHvPCCyXqtD5DqJeNxl2dtTyhF78xXNXdkwX1CZeRusQfRKp+tA7hAShOK/B/fQ2" crossorigin="anonymous"></script>
    -->
</body>

</html><?php /**PATH E:\Development\RogProjects\upwork\IGaming\resources\views/welcome.blade.php ENDPATH**/ ?>